O pacote contraste permite aplicar contrastes de forma otimizada e personalizada por classes de uso e cobertura do solo. 

Na forma otimizada, o pacote aplica os melhores algoritmos de contraste por classes registradas no Mapbiomas.
Na parte personalizada, o pacote permite o usuário aplicar os contrastes desejados para cada classe constante na cena.


Este pacote foi desenvolvido como requisito para o trabalho final da disciplina de Introdução à Programação para Sensoriamento Remoto - SER-347.

Para utilização do pacote contraste é necessária a instalação do pacote gdal, versão igual ou superior a 3.3.0 (https://gdal.org/).
