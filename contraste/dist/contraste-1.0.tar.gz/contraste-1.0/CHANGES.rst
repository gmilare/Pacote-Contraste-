Versão 1.0.0
------------

- Primeira versão estável do pacote